#ifndef _COUNTBLOCK_H_
#define _COUNTBLOCK_H_
void CountBlock(char *filename,int *blockno, int *mediumno,int *vertexno);
#endif
