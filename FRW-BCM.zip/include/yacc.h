#ifndef _YACC_H_
#define _YACC_H_
struct Var
{
   char name[32];
   int type;
   int tno;
   int blkno;
   char layer;
}; 
#endif
